/* 
 * File:   genacje_salzmamy_PacketDropper.h
 * Author: James
 *
 * Created on May 7, 2011, 6:06 PM
 */

#ifndef GENACJE_SALZMAMY_PACKETDROPPER_H
#define	GENACJE_SALZMAMY_PACKETDROPPER_H

#include <iostream>
using namespace std;

class PacketDropper {
public:
    PacketDropper();
    PacketDropper(const PacketDropper& orig);
    virtual ~PacketDropper();
    
    // drops a packet if the id matches ids[index]
    bool is_specified_to_drop(long id);

private:
    int n_d;
    long* ids_d;
    int index_d;

    void get_n_dropped();
    void get_ids_dropped(); // enter in order



};

#endif	/* GENACJE_SALZMAMY_PACKETDROPPER_H */

