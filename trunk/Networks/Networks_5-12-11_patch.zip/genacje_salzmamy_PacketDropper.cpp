/* 
 * File:   genacje_salzmamy_PacketDropper.cpp
 * Author: James
 * 
 * Created on May 7, 2011, 6:06 PM
 */

#include "genacje_salzmamy_PacketDropper.h"

PacketDropper::PacketDropper() {
    get_n_dropped();

    if (n_d > 0) {
        ids_d = new long[n_d];
        memset(ids_d, '\0', sizeof(long)*n_d);
        get_ids_dropped();
    }
}

PacketDropper::PacketDropper(const PacketDropper& orig) {
}

PacketDropper::~PacketDropper() {
    if (n_d > 0) {
        delete [] ids_d;
    }
}

// drops a packet if the id matches ids[index]
bool PacketDropper::is_specified_to_drop(long id) {
    if (n_d == 0) {
        return false; // didn't specify any to drop
    } else if ((index_d + 1) >= n_d) {
        return false; // all have been dropped
    } else if (ids_d[index_d] != id) {
        return false; // not specified to drop
    } else {
        cout << "~~Packet Drop Simulator: " << id << " dropped!~~" << endl;
        index_d++;
        return true; // dropped this
    }
}

void PacketDropper::get_n_dropped() {
    cin.ignore(2048, '\n');

    do {
        cout << "Enter the number of packets to drop: " << endl;
        cin >> n_d;
    } while (n_d > 15);
}

void PacketDropper::get_ids_dropped() {
    cout << "Enter the packet ids to drop (in order for proper function): " << endl;

    for (int i = 0; i < n_d; i++) {
        cout << "Packet id #" << (i+1) << ": ";
        cin >> ids_d[i];
        cout << endl;
    }
}


